export { default } from './NavSectionVertical';
