export { default } from './LoginLayout';
